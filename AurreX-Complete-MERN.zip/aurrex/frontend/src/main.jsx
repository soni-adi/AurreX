import React from 'react'
import ReactDOM from 'react-dom/client'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import App from './App.jsx'
import './index.css'
const qc = new QueryClient({ defaultOptions:{ queries:{ retry:1, staleTime:30000 } } })
ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode><QueryClientProvider client={qc}><App/></QueryClientProvider></React.StrictMode>
)